function varargout=mechanism_mpc(action,varargin)
% Controller boundary: own measurement and decoded packet forecasts only.
switch action
 case 'prepare',varargout{1}=prepare(varargin{:});
 case 'solve',[varargout{1:nargout}]=solve(varargin{:});
end
end
function c=prepare(m,cfg)
if ~isfield(cfg,'cooperative_horizon'),cfg.cooperative_horizon=cfg.N;end
c.m=m;c.cfg=cfg;c.N=cfg.N;c.n=3*c.N;
c.F=zeros(12*c.N,12);c.G=zeros(12*c.N,c.n);
for a=1:c.N
 ix=(a-1)*12+(1:12);c.F(ix,:)=m.As^a;
 for b=1:a,c.G(ix,(b-1)*3+(1:3))=m.As^(a-b)*m.Bs;end
end
Q=diag(cfg.Q);Ru=diag(cfg.R);[~,Pf]=dlqr(m.As,m.Bs,Q,Ru);
c.Qbar=kron(eye(c.N),Q);c.Qbar(end-11:end,end-11:end)=Pf;
c.Rbar=kron(eye(c.N),Ru);c.H=2*(c.G'*c.Qbar*c.G+c.Rbar);
c.posrows=reshape((0:c.N-1)'*12+(7:9),[],1);
c.opts=optimoptions('quadprog','Display','off','Algorithm','interior-point-convex', ...
 'OptimalityTolerance',1e-7,'ConstraintTolerance',1e-7,'MaxIterations',100);
c.inner=expm([m.Ac m.Bc;zeros(3,15)]*cfg.h);
end
function [U,meta]=solve(c,own,ref,neighbors,lower,upper,base)
% ref/base: physical 12 x (N+1); neighbors: receiver-generated predictions.
m=c.m;N=c.N;x0=m.Dx\(own-base(:,1));
target=m.Dx\(ref(:,2:end)-base(:,2:end));
free=c.F*x0;H=c.H;f=2*c.G'*c.Qbar*(free-target(:));
nc=numel(neighbors);nsl=2*nc;AA=zeros(0,c.n+nsl);bb=zeros(0,1);
for j=1:nc
 nb=neighbors{j};pTarget=nb.position+(ref(7:9,2:end)-nb.reference);
 rows=reshape((0:N-1)'*12+(7:9),[],1); % order N north, N east, N down
 vec=reshape(m.Dx\[zeros(6,N);pTarget-base(7:9,2:end);zeros(3,N)],[],1);
 Gp=c.G(rows,:);d=free(rows)-vec(rows);q=c.cfg.formation_weight;
 H=H+2*q*(Gp'*Gp);f=f+2*q*Gp'*d;
 for k=2:3:min(N,c.cfg.cooperative_horizon)
  row=(k-1)*12+8;g=2*c.G(row,:);p0=2*free(row)+base(8,k+1);
  s=sign(ref(8,k+1)-nb.reference(2,k));if s==0,s=1;end
  r=c.cfg.own_position_reserve(2)+nb.radius(2,k);
  a=zeros(1,c.n+nsl);a(1:c.n)=-s*g;a(c.n+2*j-1)=-1;
  AA=[AA;a];bb=[bb;s*(p0-nb.position(2,k))-c.cfg.safety_distance-r];
  for sg=[-1 1]
   a=zeros(1,c.n+nsl);a(1:c.n)=sg*g;a(c.n+2*j)=-1;
   desired=ref(8,k+1)-nb.reference(2,k);
   AA=[AA;a];bb=[bb;c.cfg.formation_bound-r-sg*(p0-nb.position(2,k)-desired)];
  end
 end
end
H=blkdiag(H,2*c.cfg.slack_penalty*eye(nsl));H=(H+H')/2+1e-9*eye(size(H));
lb=[reshape(m.Su\(lower-m.trim.command),[],1);zeros(nsl,1)];
ub=[reshape(m.Su\(upper-m.trim.command),[],1);inf(nsl,1)];
started=tic;
[v,~,flag,out]=quadprog(H,[f;zeros(nsl,1)],AA,bb,[],[],lb,ub,[],c.opts);
elapsed=toc(started);
if flag<=0 || isempty(v),error('MECHANISM:SolverFailure','QP flag %d: %s',flag,out.message);end
U=m.trim.command+m.Su*reshape(v(1:c.n),3,N);
meta=struct('flag',flag,'iterations',out.iterations,'seconds',elapsed, ...
 'max_slack',max([0;v(c.n+1:end)]),'qp_constraint_residual',max([0;AA*v-bb]), ...
 'prediction',base(:,2:end)+m.Dx*reshape(free+c.G*v(1:c.n),12,N));
end
