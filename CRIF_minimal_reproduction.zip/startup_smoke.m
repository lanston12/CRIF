function root = startup_smoke()
% Add only this project's code and pinned MSS support paths.
root = fileparts(mfilename('fullpath'));
folders = {'config','plant','prediction','control','experiments','analysis'};
for k=1:numel(folders), addpath(fullfile(root,folders{k})); end
mss=fullfile(root,'external','MSS_pinned');
assert(isfolder(mss),'Pinned MSS checkout missing.');
addpath(genpath(fullfile(mss,'LIBRARY')));
addpath(fullfile(mss,'GNC'));
addpath(fullfile(mss,'INS','functions'));
addpath(genpath(fullfile(mss,'HYDRO')));
addpath(fullfile(mss,'CRAFT','AUV','models'));
end
