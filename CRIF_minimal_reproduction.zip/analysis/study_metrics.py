"""Definitions and immutable-log extraction for the empirical statistical study."""
from pathlib import Path
import hashlib,json
import numpy as np
from scipy.io import loadmat
R=Path(__file__).resolve().parents[1]
TRIM_COMMAND=loadmat(R/'config/remus100_linear_model.mat',simplify_cells=True)['model']['trim']['command']
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def read(p):return loadmat(p,simplify_cells=True)['result']
def records(a):
 if isinstance(a,dict):return [a]
 if isinstance(a,np.ndarray):return list(a.flat)
 return list(a)
def formation(r):
 e=r['state'][6:9]-r['reference'][6:9]
 return np.array([np.linalg.norm(e[:,i]-e[:,j],axis=0) for i in range(3) for j in range(i+1,3)])
def separation(r):
 x=r['state'][6:9];return np.array([np.linalg.norm(x[:,i]-x[:,j],axis=0) for i in range(3) for j in range(i+1,3)])
def metrics(p):
 r=read(p);c=r['config'];t=r['time'];dt=c['Ts'];fe=formation(r);dist=separation(r)
 er=r['state'][6:9]-r['reference'][6:9];finite=lambda a:np.asarray(a)[np.isfinite(a)]
 aoi=finite(r['aoi']);crif=finite(r['crif']);margin=finite(r['margin']);failed=bool(r['failed'])
 after=c['interaction_end'] if r['experiment']!='E4' else c['blackout'][1]
 valid=np.max(fe,axis=0)<=c['recovery_threshold_m'];hold=round(c['recovery_hold_s']/dt)+1
 ix=[i for i in range(len(t)-hold+1) if t[i]>=after and np.all(valid[i:i+hold])]
 recovery=t[ix[0]]-after if ix else np.nan
 phys=np.any(r['applied_min']<np.array(c['input_floor'])[:,None,None]-1e-9,axis=(0,1))|np.any(r['applied_max']>np.array(c['input_limit'])[:,None,None]+1e-9,axis=(0,1))
 physical_state=(np.any(abs(r['state'][10])>.15,axis=0)|np.any(abs(r['state'][11])>.5,axis=0)|np.any(abs(r['state'][1])>.35,axis=0)|(np.min(dist,axis=0)<c['safety_distance']))
 acc=r['acceleration_max']/np.array(c['acceleration_bound'])[:,None,None]
 residual=abs(r['residual'])/np.array(c['W_physical'])[:,None,None]
 service=r.get('service',{});e3=r['experiment']=='E3'
 broadcasts=int(np.sum(r['transmit']))
 bits=int(r['bits'])
 if e3:
  txs=records(service['txlog']);broadcasts=sum(x['kind'] in ['source','service'] and x['start']<c['duration'] for x in txs)
  bits=int(r['initial_message_bits'])+sum(max(0,min(int(x['bits']),int(round((min(c['duration'],x['finish'])-x['start'])*c['channel_bitrate'])))) for x in txs)
 out=dict(experiment=r['experiment'],method=r['method'],seed=int(r['seed']),failed=int(failed),
  formation_RMSE_m=float(np.sqrt(np.mean(fe**2))),trajectory_RMSE_m=float(np.sqrt(np.mean(np.sum(er**2,axis=0)))),
  max_formation_error_m=float(np.max(fe)),P95_formation_error_m=float(np.percentile(fe,95)),
  recovery_time_s=float(recovery),recovery_censored=int(not ix),
  control_effort_scaled_s=float(dt*np.sum(((r['commands']-TRIM_COMMAND[:,None,None])/np.array([.1,.1,300])[:,None,None])**2)/3),
  min_separation_m=float(np.nanmin(dist)),min_robust_margin_m=float(np.min(margin)),
  negative_margin_fraction=float(np.mean(np.nanmin(r['margin'],axis=(0,1))<0)),
  physical_constraint_violations=int(np.sum(phys)+np.sum(physical_state)),MPC_failures=int(failed),
  broadcasts=broadcasts,on_air_bits=bits,retries=int(r['retries']),acknowledgments=int(np.sum(r['acknowledgments'])),
  acoustic_occupancy=float(bits/c['channel_bitrate']/c['duration']),
  mean_AoI_s=float(np.mean(aoi)),max_AoI_s=float(np.max(aoi)),CRIF_mean=float(np.mean(crif)),CRIF_P95=float(np.percentile(crif,95)),CRIF_max=float(np.max(crif)),
  deadline_misses=int(r['deadline_misses']),acceleration_envelope_max_ratio=float(np.nanmax(acc)),physical_residual_max_ratio=float(np.nanmax(residual)),
  prediction_coverage=float(np.mean(finite(r['coverage']))),completed_steps=int(r['completed_steps']),
  solver_fallbacks=int(np.sum(r.get('solver_fallback',0))),
  log_path=str(Path(p).relative_to(R)).replace('\\','/'),log_sha256=sha(p),config_sha256=sha(R/r['config_path']))
 # Event definitions are evaluated at the actual service opportunities.
 near=0;suppressed=0
 for k in range(0,len(t)-1,round(c['channel_interval']/dt)):
  for j in range(3):
   near+=int(r['transmit'][j,k]>0 and np.nanmin(r['budget'][:,j,k])<=c['near_constraint_threshold_m'])
   suppressed+=int(np.nanmax(r['aoi'][:,j,k])>=c['aoi_threshold'] and np.nanmax(r['crif'][:,j,k])<c['crif_threshold'] and r['transmit'][j,k]==0 and r['pending'][j,k]==0)
 out['events_near_constraints']=near;out['low_relevance_opportunities_not_transmitted']=suppressed
 if failed:
  # Partial trajectories are retained but must never enter full-mission means.
  for key in ['formation_RMSE_m','trajectory_RMSE_m','max_formation_error_m','P95_formation_error_m','control_effort_scaled_s','recovery_time_s']:
   out[key]=float('nan')
 return out
def mean_ci(a,seed=90215,B=10000):
 a=np.asarray(a,dtype=float)
 if not np.all(np.isfinite(a)):return [float('nan')]*3
 ids=np.random.default_rng(seed).integers(0,len(a),(B,len(a)));boot=np.mean(a[ids],axis=1)
 return [float(np.mean(a)),*map(float,np.quantile(boot,[.025,.975]))]
def paired(a,b):
 d=np.asarray(b)-np.asarray(a);v=mean_ci(d)
 return dict(mean_difference=v[0],median_difference=float(np.median(d)),CI95_low=v[1],CI95_high=v[2])
def job_metrics(r):
 rows=records(r['service']['rows']);jobs=[]
 for jid in sorted(set(x['job'] for x in rows)):
  rr=[x for x in rows if x['job']==jid];v=dict(rr[0])
  for key in ['delta_margin','uncertainty_reduction','before_uncertainty','after_uncertainty','margin_hold','margin_after','crif_reduction','applied_delta_margin']:
   v[key]=float(np.mean([x[key] for x in rr]))
  v['accepted_fraction']=float(np.mean([x['accepted'] for x in rr]));jobs.append(v)
 return jobs
if __name__=='__main__':
 import sys
 for p in sys.argv[1:]:print(json.dumps(metrics(R/p),indent=2))
