"""Offline matched-trace diagnostics. Ground truth is used only for sensor/audit data."""
from pathlib import Path
import numpy as np
from scipy.io import loadmat,savemat
import json
R=Path(__file__).resolve().parents[1]
M=loadmat(R/'config/remus100_linear_model.mat',simplify_cells=True)['model']

def packets(run):
    p=run['packet_payloads']
    return list(p) if isinstance(p,(list,np.ndarray)) else [p]

def forecast(p,at,c):
    age=int(at-p['step']);assert age>=0
    if c.get('forecast_mode')=='CV_ACCELERATION_CONTRACT':
        tau=age*c['Ts'];cap=min(tau,c['contract_TTL']);x=np.asarray(p['state']).copy();x[6:9]+=tau*p['velocity'];r=np.asarray(p['radius']).copy()
        r[6:9]+=np.array(p.get('velocity_radius',c['velocity_error']))*cap+.5*np.array(c['acceleration_bound'])*cap**2+c['expired_velocity_error']*max(0,tau-c['contract_TTL'])
        return x,r
    A,B=M['A'],M['B'];x=np.asarray(p['state']).copy();u=np.asarray(p['U']);rr=np.zeros(12);P=np.eye(12)
    for q in range(age):
        b=M['trim']['x'].copy();b[6]+=1.5*(p['step']+q)*c['Ts'];bn=b.copy();bn[6]+=1.5*c['Ts']
        x=bn+A@(x-b)+B@(u[:,min(q,u.shape[1]-1)]-M['trim']['command'])
        beta=c['contract_beta'] if at-1-q<=p['expiry'] else np.array(c['input_limit'])-c['input_floor']
        rr+=abs(P)@c['W_physical']+abs(P@B)@beta;P=A@P
    rr+=abs(P)@p['radius']
    return x,rr

def save(stem,data,stage,version):
    folder=R/'logs/mechanisms'/stage/version;folder.mkdir(parents=True,exist_ok=True)
    dest=folder/(stem+'.mat')
    if dest.exists():raise FileExistsError(dest)
    savemat(dest,{'result':data},long_field_names=True)

def equal_age(c,run,stage):
    pp=packets(run);p=min([p for p in pp if p['id']==2 and p['step']*c['Ts']>=20],key=lambda p:p['step'])
    ages=np.arange(0,6+c['Ts']/2,c['Ts']);steps=np.rint(ages/c['Ts']).astype(int)+int(p['step'])
    support=[];error=[];budget=[];margin=[];crif=[];centers=[]
    for step in steps:
        xp,rp=forecast(p,step,c);truth=run['state'][:,1,step]
        # Two translated copies of the same nonlinear plant solution: exact position-translation symmetry.
        pred_err=xp[7]-truth[7]
        b=np.minimum(np.array([c['far_offset'],c['near_offset']])+pred_err-c['safety_distance']-c['own_position_reserve'][1],c['formation_bound']-abs(pred_err)-c['own_position_reserve'][1])
        support.append(rp[7]);error.append(np.linalg.norm(truth[6:9]-xp[6:9]));budget.append(b);margin.append(b-rp[7]);crif.append(rp[7]/np.maximum(.01,b));centers.append(xp[6:9])
    out={'age':ages,'support':np.array(support),'raw_error':np.array(error),'budget':np.array(budget),
         'margin':np.array(margin),'crif':np.array(crif),'source_packet':p,'source_steps':steps,
         'config':c,'design':'Matched translated nonlinear trajectories, identical packets/errors, different separation slack. No separate fabricated FAR/NEAR curves.'}
    save('E1_equal_age',out,stage,c['version']);return out

def delivery_legacy(c,run,stage):
    rng=np.random.default_rng(c['evaluation_seed'] if stage=='evaluation' else 1101)
    pp=packets(run);sender=2;own=0;ps=[p for p in pp if p['id']==sender]
    release_times=np.arange(10,c['duration']-7,2.0)
    rows=[];jobs=[];obs=[]
    def latest(cut):return max([p for p in ps if p['step']<=cut],key=lambda p:p['step'])
    def held(at):
        ver=int(run['active_version'][own,sender-1,at]);return next(p for p in ps if p['version']==ver)
    def margin(p,at):
        xp,r=forecast(p,at,c);ownp=run['state'][7,own,at];desired=run['reference'][7,sender-1,at]-run['reference'][7,own,at]
        b=min(xp[7]-ownp-c['safety_distance'],c['formation_bound']-abs(xp[7]-ownp-desired))-c['own_position_reserve'][1]
        return b-r[7],r[7],r[7]/max(.01,b),xp,r
    for jobid,t in enumerate(release_times):
        k=round(t/c['Ts']);hp=held(k);up=latest(k-round(.8/c['Ts']));direct=latest(k-round(1.6/c['Ts']))
        prior,rad=forecast(up,k,c);measurement=run['state'][6:9,sender-1,k]+rng.uniform(-1,1,3)*c['edge_observation_radius']
        lower=np.maximum(prior[6:9]-rad[6:9],measurement-c['edge_observation_radius']);upper=np.minimum(prior[6:9]+rad[6:9],measurement+c['edge_observation_radius'])
        nonempty=bool(np.all(lower<=upper));obs.append({'step':k,'measurement':measurement,'lower':lower,'upper':upper,'intersection_nonempty':nonempty})
        edge=dict(up);edge['step']=k;edge['state']=prior.copy();edge['radius']=rad.copy();edge['source_step']=k
        if c.get('forecast_mode')=='CV_ACCELERATION_CONTRACT':
            edge['velocity_radius']=np.array(up.get('velocity_radius',c['velocity_error']))+np.array(c['acceleration_bound'])*(k-up['step'])*c['Ts']
            edge['expiry']=k+round(c['contract_TTL']/c['Ts'])
        shift=k-int(up['step']);edge['U']=up['U'][:,np.minimum(np.arange(c['N'])+shift,c['N']-1)]
        if nonempty:edge['state'][6:9]=(lower+upper)/2;edge['radius'][6:9]=(upper-lower)/2
        # Declared processing/queue regime varies independently of method and outcomes.
        extra=2.4 if 28<=t<44 or 64<=t<72 else 0
        modes=[('FORWARD',up,c['forward_delay'],0,2*c['packet_bits']),
               ('LOCAL',direct,c['local_delay'],c['local_delay'],c['packet_bits']),
               ('EDGE',edge,c['edge_delay']+extra,.4+extra,2*c['packet_bits']+192),
               ('SKIP',hp,0,0,0)]
        estimates=[];jobrows=[]
        for mode,p,delay,compute,bits in modes:
            at=k+int(np.ceil(delay/c['Ts']-1e-12));before=margin(held(at),at);after=margin(p,at)
            delta=after[0]-before[0];heldrelease=margin(hp,at)
            estimated=after[1]-heldrelease[1] # centers/truth are excluded from selection
            valid=nonempty or mode!='EDGE'
            estimates.append((-estimated-.00003*bits) if valid else -np.inf)
            error=run['state'][6:9,sender-1,at]-after[3][6:9]
            row={'job':jobid,'release':t,'application':at*c['Ts'],'mode':mode,'source_age':(at-p['source_step'])*c['Ts'],
                 'support':after[1],'crif':after[2],'margin_before':before[0],'margin_after':after[0],
                 'delta_margin':delta,'bits':bits,'computation_latency':compute,'total_delay':delay,
                 'useful':bool(delta>1e-9),'intersection_nonempty':valid,'coverage':bool(np.all(abs(error)<=after[4][6:9]+1e-9))}
            # SKIP applies no old packet; the held state stays as it is.
            if mode=='SKIP':row.update(delta_margin=0.,margin_after=before[0],useful=False)
            rows.append(row);jobrows.append(row)
        pick=int(np.argmax(estimates));adaptive=dict(jobrows[pick]);adaptive.update(mode='ADAPTIVE',chosen=jobrows[pick]['mode']);rows.append(adaptive)
        jobs.append({'release':t,'estimated_support_gain_minus_cost':estimates,'chosen':jobrows[pick]['mode']})
    data={'rows':rows,'jobs':jobs,'observations':obs,'config':c,
          'scope':'Matched-trace application-time ablation; counterfactual jobs do not feed back into the source nonlinear trajectory.'}
    save('E3_delivery',data,stage,c['version'])
    (R/'logs/mechanisms'/stage/c['version']/'E3_delivery.json').write_text(json.dumps(data,default=lambda a:a.tolist() if isinstance(a,np.ndarray) else a,indent=2))
    return data

def delivery(c,run,stage,stem='E3_delivery'):
    """Independent receiver caches and pending jobs on a common nonlinear trace.

    Packet/sensor access is explicit. Adaptive ranking reads only available
    certificates and pending completions; future truth is reserved for audits.
    """
    rng=np.random.default_rng(c['evaluation_seed'] if stage=='evaluation' else int(run.get('seed',1101)))
    ps=[p for p in packets(run) if p['id']==2]
    dt=c['Ts'];rows=[];jobs=[];observations=[];policies=['FORWARD','LOCAL','EDGE','ADAPTIVE']
    cache={p:min(ps,key=lambda x:x['step']) for p in policies};queue={p:[] for p in policies}
    def latest(cut):return max([p for p in ps if p['step']<=max(0,cut)],key=lambda p:p['step'])
    cache={policy:latest(round(6/dt)) for policy in policies} # same already-delivered bootstrap, source t=6 s
    def metrics(p,at):
        xp,r=forecast(p,at,c);ownp=run['state'][7,0,at];desired=run['reference'][7,1,at]-run['reference'][7,0,at]
        b=min(xp[7]-ownp-c['safety_distance'],c['formation_bound']-abs(xp[7]-ownp-desired))-c['own_position_reserve'][1]
        return b-r[7],r[7],r[7]/max(.01,b),xp,r
    def drain(policy,until):
        due=sorted([q for q in queue[policy] if q['at']<=until],key=lambda q:(q['at'],q['job']))
        queue[policy]=[q for q in queue[policy] if q['at']>until]
        for q in due:
            p=q['packet'];at=q['at'];before=metrics(cache[policy],at);after=metrics(p,at);delta=after[0]-before[0]
            accepted=bool(q['valid'] and delta>1e-9)
            error=run['state'][6:9,1,at]-after[3][6:9]
            row={k:v for k,v in q.items() if k not in ['packet','at','valid']}
            row.update(application=at*dt,source_age=(at-p['source_step'])*dt,velocity_source_age=(at-q['velocity_source'])*dt,
              support=after[1],crif=after[2],margin_before=before[0],margin_after=after[0],delta_margin=delta,
              applied_delta_margin=delta if accepted else 0.,accepted=accepted,useful=bool(delta>1e-9),
              intersection_nonempty=q['valid'],coverage=bool(np.all(abs(error)<=after[4][6:9]+1e-9)))
            rows.append(row)
            if accepted:cache[policy]=p
    for jid,t in enumerate(np.arange(10,c['duration']-7,2.)):
        k=round(t/dt)
        for policy in policies:drain(policy,k)
        # Direct path: 3-second sampling with known transport delay; upstream: 1 second.
        direct_delay=3.2 if 20<=t<50 or 60<=t<72 else 1.6
        direct=latest(round(np.floor((t-direct_delay)/3)*3/dt));up=latest(round(np.floor(t-.8)/dt))
        prior,rad=forecast(up,k,c)
        measured=run['state'][6:9,1,k]+rng.uniform(-1,1,3)*c['edge_observation_radius']
        low=np.maximum(prior[6:9]-rad[6:9],measured-c['edge_observation_radius']);high=np.minimum(prior[6:9]+rad[6:9],measured+c['edge_observation_radius'])
        valid=bool(np.all(low<=high));observations.append({'step':k,'measurement':measured,'lower':low,'upper':high,'intersection_nonempty':valid})
        edge=dict(up);edge.update(step=k,source_step=k,expiry=k+round(c['contract_TTL']/dt),state=prior.copy(),radius=rad.copy())
        edge['velocity_radius']=np.array(up['velocity_radius'])+np.array(c['acceleration_bound'])*(k-up['step'])*dt
        if valid:edge['state'][6:9]=(low+high)/2;edge['radius'][6:9]=(high-low)/2
        extra=2.4 if 28<=t<44 or 64<=t<72 else 0
        modes={'FORWARD':(up,c['forward_delay'],0,2*c['packet_bits'],True,up['step']),
               'LOCAL':(direct,c['local_delay'],c['local_delay'],c['packet_bits'],True,direct['step']),
               'EDGE':(edge,c['edge_delay']+extra,.4+extra,2*c['packet_bits']+192,valid,up['step'])}
        # Predict support gain at completion against all ALREADY pending certificates.
        nextdecision=k+round(2/dt)
        known_next=[cache['ADAPTIVE']]+[q['packet'] for q in queue['ADAPTIVE'] if q['at']<=nextdecision and q['valid']]
        utilities={'SKIP':-min(forecast(h,nextdecision,c)[1][7] for h in known_next)};details={}
        for mode,(p,delay,compute,bits,ok,vs) in modes.items():
            at=k+int(np.ceil(delay/dt-1e-12));known=[cache['ADAPTIVE']]+[q['packet'] for q in queue['ADAPTIVE'] if q['at']<=at and q['valid']]
            held_support=min(forecast(h,at,c)[1][7] for h in known)
            gain=held_support-forecast(p,at,c)[1][7]
            if mode!='FORWARD':utilities[mode]=-forecast(p,at,c)[1][7]-.1*delay-c.get('edge_bit_cost',.0001)*bits if ok and gain>1e-9 else -1e9
            details[mode]={'predicted_support_gain':gain,'completion':at*dt}
        choice=max(utilities,key=utilities.get);jobs.append({'release':t,'choice':choice,'utilities':utilities,'predicted':details,'direct_delay':direct_delay,'edge_extra_queue':extra})
        for policy in policies:
            mode=choice if policy=='ADAPTIVE' else policy
            if mode=='SKIP':
                before=metrics(cache[policy],k)
                rows.append({'job':jid,'release':t,'application':t,'mode':policy,'chosen':'SKIP','source_age':(k-cache[policy]['source_step'])*dt,
                  'velocity_source_age':(k-cache[policy]['step'])*dt,'support':before[1],'crif':before[2],'margin_before':before[0],'margin_after':before[0],
                  'delta_margin':0.,'applied_delta_margin':0.,'accepted':False,'useful':False,'bits':0,'computation_latency':0.,'total_delay':0.,'intersection_nonempty':True,'coverage':bool(np.all(abs(run['state'][6:9,1,k]-before[3][6:9])<=before[4][6:9]+1e-9))})
                continue
            p,delay,compute,bits,ok,vs=modes[mode];at=k+int(np.ceil(delay/dt-1e-12))
            queue[policy].append({'job':jid,'release':t,'at':at,'mode':policy,'chosen':mode,'packet':p,'valid':ok,'velocity_source':vs,
                                 'bits':bits,'computation_latency':compute,'total_delay':delay})
    for policy in policies:drain(policy,len(run['time'])-1)
    data={'rows':rows,'jobs':jobs,'observations':observations,'config':c,'bootstrap_bits_per_policy':c['packet_bits'],
      'scope':'Common nonlinear C2 trace with separate receiver-cache/job event simulations. No counterfactual mode feeds back into the plant. Signed delivered-candidate gains include rejected results; applied gains are separately recorded.'}
    save(stem,data,stage,c['version'])
    (R/'logs/mechanisms'/stage/c['version']/(stem+'.json')).write_text(json.dumps(data,default=lambda a:a.tolist() if isinstance(a,np.ndarray) else a,indent=2))
    return data

if __name__=='__main__':
    import argparse
    ap=argparse.ArgumentParser();ap.add_argument('config');ap.add_argument('stage');ap.add_argument('seed',type=int);a=ap.parse_args()
    c=json.loads((R/a.config).read_text());folder=R/'logs/mechanisms'/a.stage/c['version']
    c2=loadmat(folder/f'C2_IDEAL_{a.seed}.mat',simplify_cells=True)['result'];equal_age(c,c2,a.stage)
    delivery(c,c2,a.stage)
