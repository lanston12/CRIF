function x= rk4_remus(x,command,current,dt,h)
steps=round(dt/h);assert(abs(steps*h-dt)<1e-10);
for j=1:steps
 k1=remus_wrapper(x,command,current);
 k2=remus_wrapper(x+h*k1/2,command,current);
 k3=remus_wrapper(x+h*k2/2,command,current);
 k4=remus_wrapper(x+h*k3,command,current);
 x=x+h*(k1+2*k2+2*k3+k4)/6;
end
assert(all(isfinite(x)),'Nonfinite integrated plant.');
end
