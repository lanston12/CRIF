function [dx,applied,U,M]=remus_wrapper(x,command,current)
% Exact pinned MSS dynamics. No replacement mass matrix or extra actuator lag.
if nargin<3,current=[0;0;0];end
assert(numel(x)==12 && numel(command)==3 && numel(current)==3);
limit=[deg2rad(20);deg2rad(20);1525];
applied=max(-limit,min(limit,command(:)));
[dx,U,M]=remus100(x(:),applied,current(1),current(2),current(3));
assert(all(isfinite(dx)),'Nonfinite MSS derivative.');
end
