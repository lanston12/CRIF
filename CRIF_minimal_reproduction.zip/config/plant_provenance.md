# Pinned plant provenance (Gate A prerequisite; Gate B not accepted)

- Repository: [official MSS](https://github.com/cybergalactic/MSS).
- Actual checkout commit: `98970f71a21cfe81e7e29abdcc1bb6741789cddc`.
- Commit timestamp: 2026-09-07T16:43:15Z; retrieved 2026-09-15, Asia/Shanghai.
- Source: [pinned remus100.m](https://github.com/cybergalactic/MSS/blob/98970f71a21cfe81e7e29abdcc1bb6741789cddc/CRAFT/AUV/models/remus100.m).
- Source SHA-256: `af003eef371e6e2c45304e096c0d22a90c683c347d223c5d9c1380208cce6d2e`.
- Source is unmodified; MIT license is retained under `external/MSS_pinned/LICENSE`.
- MATLAB: 9.13.0.2049777 (R2022b) (PCWIN64); installed executable `D:/MATLAB/R2022b/bin/matlab.exe`.
- Plant needs MATLAB; preparation uses Optimization Toolbox (fsolve) and Control System Toolbox (dlqr,dlyap,ctrb). quadprog is available but no MPC solver was run. The MATLAB Symbolic toolbox license probe was positive but `syms` was unavailable; independent symbolic checks use SymPy 1.14.0. The optional MATLAB symbolic file is not counted as a pass.
- Sparse checkout contains CRAFT/AUV/models, LIBRARY, GNC, INS/functions and HYDRO. `startup_smoke.m` adds these paths. Exact dependency inventory below was obtained with `matlab.codetools.requiredFilesAndProducts`; it includes inactive quaternion/Hoerner branches as static dependencies.

No 2027 source-comment book is cited as already published. Standard equations cite [Fossen, second edition, 2021](https://onlinelibrary.wiley.com/doi/book/10.1002/9781119575016). The exact plant is the software revision, not an inferred manufacturer datasheet. [Allen et al., OCEANS 2000](https://doi.org/10.1109/OCEANS.2000.882209) is historical propulsion background; its full text was not used to replace the pinned model coefficients.

## File inventory and hashes

| Required MSS file | SHA-256 |
|---|---|
| CRAFT/AUV/models/remus100.m | af003eef371e6e2c45304e096c0d22a90c683c347d223c5d9c1380208cce6d2e |
| GNC/sat.m | 6801870cde7d7887f7a67810d045da91f2bad70a42866f63a1a0434c224b041a |
| HYDRO/Hoerner.m | fa1873ccf3244e7f33ab0e75c72a1022023bb28f0cc5ab192a111c109060b78c |
| HYDRO/cylinderDrag.m | 9b4c1a9875dec9d60d1dd7e5ad4c3a0c4e2c156975e4a6a94714772bf2b99dd1 |
| INS/functions/gravity.m | 0fc1f5bce40c16d52ac274f729bbe77ca375e9313163bded488dd6cb8380b6ba |
| LIBRARY/kinematics/Hmtrx.m | 3791e12789ecc2de0b5f6c8d05c5d6e54a8a2e547fa3a1a215bb3da2c0611d8e |
| LIBRARY/kinematics/Rquat.m | 3414ca1484728e94d8793f5a07173af4737cbd9117a549f227113edc0b9959e4 |
| LIBRARY/kinematics/Rzyx.m | c45efd0b5d62f6813b45216a211511803e374c2dd4668dbc4801f26f93f45390 |
| LIBRARY/kinematics/Smtrx.m | 47441ebf29d338e41d5c5055a2379883feed6e07ffa1ee379755f3d1cdcef678 |
| LIBRARY/kinematics/Tquat.m | 07e11ef58da92b6fb069db29f7d193f3144e3fcfffa918b606c5358874b817d0 |
| LIBRARY/kinematics/Tzyx.m | 1e20d293b5dca02d332ed6993681b58a8d19f5435ea92f7b6dd7be50c79e93ba |
| LIBRARY/kinematics/eulerang.m | 657c45e3d1ad44a4f9367cff0881967b0116e0f5845a18e508df49af88d5eda5 |
| LIBRARY/kinematics/quatern.m | c7466be6c455aa7c56cca8d8f951a48eb19144a1cb935b2b9da9d0fd3c41ad8c |
| LIBRARY/modeling/Dmtrx.m | 044a58426cd39b9d0bd5d520d73085e9571d88574ee0bddfc0e82310ca8ec4c4 |
| LIBRARY/modeling/coeffLiftDrag.m | 22117cd12646bf2a26b03c950a243fd3f710f01e34faaa1f1e3ac1c6128d01e1 |
| LIBRARY/modeling/crossFlowDrag.m | 543d4a18e64e2ba1b6554981bed34cc028e80c5876e2eaac3adab91a0045b476 |
| LIBRARY/modeling/forceLiftDrag.m | 081a1cfd1f278c429d3b3482f3be25170c09630843e9aaeec57bf33002b82401 |
| LIBRARY/modeling/gRvect.m | dc874786cdb8982e939b1d83491c9614bd2d6ecd436e09ae91602440ab34c16f |
| LIBRARY/modeling/imlay61.m | 21bf354d7793abf336e6d159e89a5104979f5f687a4813d55207d10bb0bf5053 |
| LIBRARY/modeling/m2c.m | 9aa45803c41a100059b98df229ced6f6e12237bf638904bd232ad3a9173e1f0c |
| LIBRARY/modeling/spheroid.m | b4ab9040251627bbfe969c7cbac2c2f16079f94d4fa6a2d10e39b26df6688f76 |

The complete implemented constants, lookup arrays and formulas are reproducible from these files. `plant_source_snapshot.txt` captures every required source including inactive static branches, with filenames and hashes. `remus100_parameters.md` distinguishes model parameters, vendor facts, design settings and unsourced quantities. These records preserve the failed witness configuration; they do not assert Gate B completion.
