function result=run_statistical_study(config_path,experiment,method,seed,stage)
% Full nonlinear closed loop. Plant state array is held only by the simulator.
root=startup_smoke();cfg=jsondecode(fileread(config_path));rng(seed,'twister'); initialStream=RandStream('mt19937ar','Seed',seed+100000); currentStream=RandStream('mt19937ar','Seed',seed+200000);
if ~isfield(cfg,'cooperative_horizon'),cfg.cooperative_horizon=cfg.N;end
outdir=fullfile(root,'logs','mechanisms',stage,cfg.version);if ~isfolder(outdir),mkdir(outdir);end
stem=sprintf('%s_%s_%d',experiment,method,seed);outfile=fullfile(outdir,[stem '.mat']);
assert(~isfile(outfile),'Run already exists; retain it and choose a new config version.');
s=load('config/remus100_linear_model.mat');m=s.model;c=study_mpc('prepare',m,cfg);
if isfield(cfg,'solver_max_iterations'),c.opts.MaxIterations=cfg.solver_max_iterations;end
N=cfg.N;dt=cfg.Ts;T=round(cfg.duration/dt);nv=3;if strcmp(experiment,'C1'),nv=1;end
% Precompute supports of full generator images, including expired-contract fallback.
maxage=T+N+100;cfg.noise_support=zeros(12,maxage+1);cfg.expired_extra=zeros(12,maxage+1);cfg.abs_power=zeros(12,12,maxage+1);P=eye(12);
for a=0:maxage
 cfg.abs_power(:,:,a+1)=abs(P);
 if a<maxage
  cfg.noise_support(:,a+2)=cfg.noise_support(:,a+1)+abs(P)*cfg.W_physical(:)+abs(P*m.B)*cfg.contract_beta(:);
  cfg.expired_extra(:,a+2)=cfg.expired_extra(:,a+1)+abs(P*m.B)*(cfg.input_limit(:)-cfg.input_floor(:)-cfg.contract_beta(:));P=m.A*P;
 end
end
x=zeros(12,nv);for i=1:nv,x(:,i)=mechanism_reference(0,i,experiment,cfg,m);x(7:9,i)=x(7:9,i)+[.15;.12;.08].*randn(initialStream,3,1);end
contracts=cell(1,nv);packets=cell(nv);versions=zeros(1,nv);plans=cell(1,nv);pending={};nextslot=0;
for i=1:nv
 plans{i}=repmat(m.trim.command,1,N);p=mechanism_packet('create',x(:,i),plans{i},0,i,cfg,m,0);
 contracts{i}={p};for j=1:nv,if i~=j,packets{j,i}=p;end,end
end
result=struct('config_path',config_path,'config',rmfield(cfg,{'noise_support','expired_extra','abs_power'}), ...
 'experiment',experiment,'method',method,'seed',seed,'stage',stage,'scope','NONCERTIFIED_EMPIRICAL', ...
 'time',(0:T)*dt,'state',nan(12,nv,T+1),'reference',nan(12,nv,T+1), ...
 'commands',nan(3,nv,T),'applied_min',nan(3,nv,T),'applied_max',nan(3,nv,T), ...
 'solver_flag',nan(nv,T),'solver_seconds',nan(nv,T),'solver_iterations',nan(nv,T), ...
 'slack',nan(nv,T),'residual',nan(12,nv,T),'aoi',nan(nv,nv,T), ...
 'crif',nan(nv,nv,T),'radius',nan(3,nv,nv,T),'margin',nan(nv,nv,T), ...
 'budget',nan(nv,nv,T),'pred_error',nan(3,nv,nv,T),'coverage',nan(nv,nv,T), ...
 'request',zeros(nv,T),'transmit',zeros(nv,T),'pending',zeros(nv,T), ...
 'expired',zeros(nv,nv,T),'contract_violation',zeros(nv,T),'version_rejects',0, ...
 'initial_message_bits',nv*cfg.packet_bits,'events',struct('step',{},'sender',{},'version',{},'delivery',{},'bits',{}));
result.state(:,:,1)=x;failed=false;errtext='';
result.packet_payloads={};for i=1:nv,result.packet_payloads{end+1}=contracts{i}{1};end
result.active_version=nan(nv,nv,T);result.control_bits=zeros(1,T);result.current=nan(3,nv,T);
result.acceleration_max=zeros(3,nv,T);result.inner_feedback_error=zeros(12,nv,T);
% Own physical support diagnostic is derived solely from local W and local feedback.
Fk=m.A+m.B*m.K;P=eye(12);pr=zeros(12,1);
for a=1:N,pr=pr+abs(P)*cfg.W_physical(:);P=Fk*P;end
result.physical_horizon_support=pr;result.physical_support=repmat(pr(7:9),1,T);
phase=rand(currentStream,3,nv)*2*pi;
result.exogenous=struct('initial_state',x,'current_phase',phase,'channel_available',true(nv,T));
result.acknowledgments=zeros(1,T);result.deadline_misses=0;result.retries=0;
result.solver_fallback=zeros(nv,T);result.error_trigger=zeros(nv,T);result.service=struct();
last_sent=-inf(1,nv);last_broadcast=contracts;
isE3=strcmp(experiment,'E3');
if isE3,net=study_service('init',packets,cfg,seed);end
try
 for k=0:T-1
  t=k*dt;ref=cell(1,nv);base=repmat(m.trim.x,1,N+1);base(7,:)=base(7,:)+1.5*(t+(0:N)*dt);
  for i=1:nv,ref{i}=mechanism_reference(t+(0:N)*dt,i,experiment,cfg,m);result.reference(:,i,k+1)=ref{i}(:,1);end
  % Only delivered messages mutate receiver storage. Monotonic version guard.
  if isE3
   [net,packets]=study_service('step',net,packets,x,plans,k,cfg,m);
  end
  keep={};
  for jj=1:numel(pending)
   job=pending{jj};
   if job.delivery<=k
    result.acknowledgments(k+1)=result.acknowledgments(k+1)+nv-1;
    if k>job.packet.expiry,result.deadline_misses=result.deadline_misses+1;end
    for i=1:nv
     if i==job.sender,continue;end
     old=packets{i,job.sender};
     [packets{i,job.sender},accepted]=mechanism_packet('accept',old,job.packet,k);
     if ~accepted,result.version_rejects=result.version_rejects+1;end
    end
   else,keep{end+1}=job;end
  end
  pending=keep;
  neighbors=cell(1,nv);scores=zeros(1,nv);ages=zeros(1,nv);
  for i=1:nv
   nn={};
   heldplan=plans{i}(:,[2:end end]);owncandidate=zeros(3,N+1);xx=x(:,i);owncandidate(:,1)=xx(7:9);
   for kk=1:N
    xx=base(:,kk+1)+m.A*(xx-base(:,kk))+m.B*(heldplan(:,kk)-m.trim.command);
    owncandidate(:,kk+1)=xx(7:9);
   end
   for j=1:nv
    if i==j,continue;end
    p=packets{i,j};result.active_version(i,j,k+1)=p.version;[pred,rad,expired]=mechanism_packet('forecast',p,k,N,cfg,m);
    nr=mechanism_reference(t+(1:N)*dt,j,experiment,cfg,m);
    nb=struct('position',pred(7:9,2:end),'radius',rad(7:9,2:end),'reference',nr(7:9,:));nn{end+1}=nb;
    horizon=min(N,cfg.cooperative_horizon);sg=sign(ref{i}(8,1)-mechanism_reference(t,j,experiment,cfg,m)'*[zeros(7,1);1;zeros(4,1)]);if sg==0,sg=1;end
    % Dynamically propagated shifted own input plan, reset at local measurement.
    sep=sg*(owncandidate(2,1:horizon+1)-pred(8,1:horizon+1));
    jr=mechanism_reference(t+(0:horizon)*dt,j,experiment,cfg,m);desired=ref{i}(8,1:horizon+1)-jr(8,:);
    ferror=abs(owncandidate(2,1:horizon+1)-pred(8,1:horizon+1)-desired);
    budget=min(sep-cfg.safety_distance-cfg.own_position_reserve(2),cfg.formation_bound-ferror-cfg.own_position_reserve(2));
    consumed=rad(8,1:horizon+1);chi=max(consumed./max(.01,budget));margin=min(budget-consumed);
    result.aoi(i,j,k+1)=(k-p.source_step)*dt;result.crif(i,j,k+1)=chi;result.margin(i,j,k+1)=margin;
    result.budget(i,j,k+1)=min(budget);result.radius(:,i,j,k+1)=rad(7:9,1);result.expired(i,j,k+1)=expired;
    % Ground truth enters the audit log only, after all scheduling quantities exist.
    er=x(7:9,j)-pred(7:9,1);result.pred_error(:,i,j,k+1)=er;result.coverage(i,j,k+1)=all(abs(er)<=rad(7:9,1)+1e-9);
    scores(j)=max(scores(j),chi);ages(j)=max(ages(j),(k-p.source_step)*dt);
   end
   neighbors{i}=nn;
  end
  for j=1:numel(pending),result.pending(pending{j}.sender,k+1)=1;end
  % Every method shares the same admission capacity, decoded messages and QP.
  errors=zeros(1,nv);
  for j=1:nv
   % B3 uses sender's own measurement against the last broadcast predictor.
   [ep,~]=mechanism_packet('forecast',last_broadcast{j}{end},k,0,cfg,m);
   errors(j)=norm(x(7:9,j)-ep(7:9));
  end
  result.error_trigger(:,k+1)=errors(:);
  if isE3,eligible=false(1,nv);priority=zeros(1,nv);
  elseif strcmp(method,'IDEAL'),eligible=true(1,nv);priority=1:nv;
  elseif strcmp(method,'AOI'),eligible=ages>=cfg.aoi_threshold;priority=ages;
  elseif strcmp(method,'CRIF'),eligible=scores>=cfg.crif_threshold | ages>=cfg.max_age;priority=scores;
  elseif strcmp(method,'PERIODIC')
   % Fixed-phase release times; no feedback of age/error/risk into releases.
   release=floor(k*dt/cfg.periodic_period)*cfg.periodic_period;
   eligible=last_sent*dt<release-1e-9;priority=k-last_sent;
  elseif strcmp(method,'ERROR'),eligible=errors>=cfg.error_threshold | ages>=cfg.max_age;priority=errors;
  else,error('Unknown scheduler');end
  if nv==1,eligible=false(1,nv);end
  result.request(:,k+1)=eligible(:);eligible=eligible & ~result.pending(:,k+1)';
  selected=[];
  if ~isE3 && nv>1 && mod(k,round(cfg.channel_interval/dt))==0
   result.control_bits(k+1)=nv*cfg.bid_packet_bits; % serialized receiver context/priority packets, counted for every method
  end
  if strcmp(method,'IDEAL'),selected=find(eligible);
  elseif mod(k,round(cfg.channel_interval/dt))==0 && any(eligible),priority(~eligible)=-inf;[~,selected]=max(priority);nextslot=k+round(cfg.channel_interval/dt);end
  for i=1:nv
   contracts{i}=contracts{i}(cellfun(@(p)p.expiry>=k,contracts{i}));
   [lo,hi]=mechanism_packet('bounds',contracts{i},k,N,cfg);
   [plans{i},meta]=study_mpc('solve',c,x(:,i),ref{i},neighbors{i},lo,hi,base);
   result.commands(:,i,k+1)=plans{i}(:,1);result.solver_flag(i,k+1)=meta.flag;result.solver_seconds(i,k+1)=meta.seconds;
   result.solver_iterations(i,k+1)=meta.iterations;result.solver_fallback(i,k+1)=meta.fallback;result.slack(i,k+1)=meta.max_slack;
  end
  for j=selected
   last_sent(j)=k;versions(j)=versions(j)+1;p=mechanism_packet('create',x(:,j),plans{j},k,j,cfg,m,versions(j));contracts{j}{end+1}=p;result.packet_payloads{end+1}=p;last_broadcast{j}={p};
   result.transmit(j,k+1)=1;delivery=k+max(1,round(cfg.channel_delay/dt));if strcmp(method,'IDEAL'),delivery=k+1;end
   blocked=strcmp(experiment,'E4') && j==cfg.blackout_sender && ((t>=cfg.blackout(1) && t<cfg.blackout(2)) || (delivery*dt>=cfg.blackout(1) && delivery*dt<cfg.blackout(2)));
   result.exogenous.channel_available(j,k+1)=~blocked;
   if ~blocked,pending{end+1}=struct('packet',p,'sender',j,'delivery',delivery);end
   result.events(end+1)=struct('step',k,'sender',j,'version',versions(j),'delivery',delivery,'bits',cfg.packet_bits);
  end
  if isE3,net=study_service('context',net,result.budget(:,:,k+1),k,cfg);end
  for i=1:nv
   old=x(:,i);nominal=old;u=plans{i}(:,1);[lo,hi]=mechanism_packet('bounds',contracts{i},k,1,cfg);
   cur=[cfg.current_magnitude+cfg.current_variation*sin(.11*t+phase(1,i));cfg.current_angle+.12*sin(.07*t+phase(2,i));.002*sin(.1*t+phase(3,i))];
   result.current(:,i,k+1)=cur;mn=inf(3,1);mx=-inf(3,1);
   for inner=1:round(dt/cfg.h)
    actual=u+m.K*(x(:,i)-nominal);actual=max(lo,min(hi,actual));
    [dd,applied]=remus_wrapper(x(:,i),actual,cur);mn=min(mn,applied);mx=max(mx,applied);
    acc=Rzyx(x(10,i),x(11,i),x(12,i))*(dd(1:3)+cross(x(4:6,i),x(1:3,i)));
    result.acceleration_max(:,i,k+1)=max(result.acceleration_max(:,i,k+1),abs(acc));
    result.inner_feedback_error(:,i,k+1)=max(result.inner_feedback_error(:,i,k+1),abs(x(:,i)-nominal));
    x(:,i)=rk4_remus(x(:,i),applied,cur,cfg.h,cfg.h);
    bt=m.trim.x;bt(7)=bt(7)+1.5*(t+(inner-1)*cfg.h);bn=bt;bn(7)=bn(7)+1.5*cfg.h;
    nominal=bn+c.inner(1:12,1:12)*(nominal-bt)+c.inner(1:12,13:15)*(u-m.trim.command);
   end
   result.applied_min(:,i,k+1)=mn;result.applied_max(:,i,k+1)=mx;
   result.contract_violation(i,k+1)=max([0;lo-mn;mx-hi]);
   result.residual(:,i,k+1)=x(:,i)-(base(:,2)+m.A*(old-base(:,1))+m.B*(u-m.trim.command));
  end
  result.state(:,:,k+2)=x;
  if mod(k+1,100)==0,fprintf('%s %s seed %d: %.1f/%.1f s, slack %.3g\n',experiment,method,seed,t+dt,cfg.duration,max(result.slack(:,k+1)));end
 end
 for i=1:nv,result.reference(:,i,T+1)=mechanism_reference(T*dt,i,experiment,cfg,m);end
catch err
 failed=true;errtext=getReport(err,'extended','hyperlinks','off');fprintf('%s\n',errtext);
end
result.failed=failed;result.error=errtext;result.completed_steps=sum(all(isfinite(result.solver_flag),1));
valid=isfinite(result.reference(7,1,:));pe=result.state(7:9,:,:)-result.reference(7:9,:,:);
result.position_RMSE=sqrt(mean(pe(:).^2,'omitnan'));
result.max_attitude=max(abs(reshape(result.state(11:12,:,:),2,[])),[],2,'omitnan');
result.max_sway=max(abs(result.state(2,:,:)),[],'all','omitnan');
result.min_separation=inf;fe=[];
for i=1:nv,for j=i+1:nv
 d=squeeze(result.state(7:9,i,:)-result.state(7:9,j,:));result.min_separation=min(result.min_separation,min(vecnorm(d),[],'omitnan'));
 de=d-squeeze(result.reference(7:9,i,:)-result.reference(7:9,j,:));fe=[fe vecnorm(de)];
end,end
result.formation_RMSE=sqrt(mean(fe.^2,'all','omitnan'));result.max_formation_error=max(fe,[],'all','omitnan');
result.bits=result.initial_message_bits+sum(result.transmit,'all')*cfg.packet_bits+sum(result.control_bits)+sum(result.acknowledgments)*cfg.ack_bits;
if isE3
 result.service=net;result.bits=net.bits+result.initial_message_bits;
 result.packet_payloads=[result.packet_payloads net.accepted_packets];
 result.deadline_misses=net.deadline_misses;
end
result.min_margin=min(result.margin,[],'all','omitnan');result.max_slack=max(result.slack,[],'all','omitnan');
result.prediction_coverage=mean(result.coverage(:),'omitnan');
save(outfile,'result','-v7');
summary=rmfield(result,{'state','reference','commands','applied_min','applied_max','solver_flag','solver_seconds','solver_iterations','slack','residual','aoi','crif','radius','margin','budget','pred_error','coverage','request','transmit','pending','expired','contract_violation','physical_support','events','packet_payloads','active_version','control_bits','current','acceleration_max','inner_feedback_error'});
fid=fopen(fullfile(outdir,[stem '.json']),'w');fprintf(fid,'%s',jsonencode(summary));fclose(fid);
fprintf('SAVED %s failed=%d posRMSE=%.3g formation=%.3g separation=%.3g margin=%.3g coverage=%.3g\n',stem,failed,result.position_RMSE,result.formation_RMSE,result.min_separation,result.min_margin,result.prediction_coverage);
end
