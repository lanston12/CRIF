function varargout=study_service(action,varargin)
% Event-driven shared acoustic medium and causal computing services.
switch action
 case 'init',varargout{1}=initialize(varargin{:});
 case 'step',[varargout{1},varargout{2}]=advance(varargin{:});
 case 'context'
  net=varargin{1};b=varargin{2};k=varargin{3};cfg=varargin{4};
  if mod(k,round(cfg.channel_interval/cfg.Ts))==0
   % Scalar receiver context reaches scheduler after the same uplink delay.
   val=min(b,[],1,'omitnan');
   [net,finish]=transmit(net,k*cfg.Ts,3*cfg.bid_packet_bits,'context',0,0,cfg);
   net.arrivals{end+1}=struct('kind','context','at',finish+cfg.e3_uplink_delay,'sender',0,'value',val);
  end
  varargout{1}=net;
end
end
function net=initialize(packets,cfg,seed)
net=struct('arrivals',{{}},'tasks',{{}},'raw_local',{{}},'raw_edge',{{}},'observations',{{}}, ...
 'busy_until',0,'edge_cpu_until',0,'local_cpu_until',zeros(1,3),'bits',0,'deadline_misses',0, ...
 'txlog',{{}},'rows',{{}},'choices',{{}},'sensor_log',{{}},'accepted_packets',{{}},'nextid',0,'budget',[7 7 7]);
for j=1:3,i=mod(j,3)+1;net.raw_local{j}=packets{i,j};net.raw_edge{j}=packets{i,j};net.observations{j}=[];end
s=RandStream('mt19937ar','Seed',seed+300000);
net.sensor_noise=2*rand(s,3,3,round(cfg.duration/cfg.Ts)+1)-1;
end
function [net,packets]=advance(net,packets,x,plans,k,cfg,m)
t=k*cfg.Ts;mode=cfg.e3_mode;
% Consume arrived payloads before any decision. No future measurements available.
keep={};
for z=1:numel(net.arrivals)
 a=net.arrivals{z};if a.at>t+1e-9,keep{end+1}=a;continue;end
 switch a.kind
  case 'raw_local',net.raw_local{a.sender}=a.value;
  case 'raw_edge',net.raw_edge{a.sender}=a.value;
  case 'sensor',net.observations{a.sender}=a.value;
  case 'context',net.budget=a.value;
  case 'service'
   job=a.value;j=a.sender;p=job.packet;
   for i=1:3
    if i==j,continue;end
    old=packets{i,j};
    [mb,cb,rb]=study_pair_value(x(:,i),plans{i},old,k,i,j,cfg,m);
    [ma,ca,ra]=study_pair_value(x(:,i),plans{i},p,k,i,j,cfg,m);
    gain=ma-mb;accepted=gain>1e-9 && p.source_step>=old.source_step && p.expiry>=k;
    if accepted,packets{i,j}=p;net.accepted_packets{end+1}=p;end
    row=struct('job',job.id,'sender',j,'receiver',i,'mode',mode,'choice',job.choice, ...
     'release',job.release,'application',t,'source_time',p.source_step*cfg.Ts, ...
     'source_age',t-p.source_step*cfg.Ts,'velocity_source_age',t-p.velocity_source_step*cfg.Ts, ...
     'latency',t-job.release,'before_uncertainty',rb,'after_uncertainty',ra, ...
     'uncertainty_reduction',rb-ra,'margin_hold',mb,'margin_after',ma,'delta_margin',gain, ...
     'crif_reduction',cb-ca,'accepted',accepted,'applied_delta_margin',accepted*gain, ...
     'bits',job.bits,'cpu_time',job.cpu,'algorithm_seconds',job.algorithm_seconds, ...
     'raw_source_time',job.raw_source_time,'observation_time',job.observation_time, ...
     'coverage',all(abs(x(7:9,j)-forecast_position(p,k,cfg,m))<=forecast_radius(p,k,cfg,m)+1e-9));
    net.rows{end+1}=row;
   end
   if p.expiry<k,net.deadline_misses=net.deadline_misses+1;end
 end
end
net.arrivals=keep;
% Complete actual CPU queues, then serialize downlinks on the shared medium.
keep={};
for z=1:numel(net.tasks)
 job=net.tasks{z};if job.ready>t+1e-9,keep{end+1}=job;continue;end
 if strcmp(job.choice,'LOCAL'),at=t;
 else,[net,finish]=transmit(net,t,job.bits,'service',job.sender,job.id,cfg);at=finish+cfg.e3_downlink_delay;end
 net.arrivals{end+1}=struct('kind','service','at',at,'sender',job.sender,'value',job);
end
net.tasks=keep;
% Common source acquisition. A receiver stores raw data but must execute a
% service before it becomes a controller certificate (same rule in all modes).
if mod(k,round(cfg.e3_source_period/cfg.Ts))==0
 j=mod(round(t/cfg.e3_source_period),3)+1;
 p=mechanism_packet('create',x(:,j),plans{j},k,j,cfg,m,k+1);p.velocity_source_step=k;
 [net,finish]=transmit(net,t,cfg.packet_bits,'source',j,k+1,cfg);
 delay=cfg.e3_direct_delay;if in_windows(t,cfg.e3_degradation_windows),delay=cfg.e3_degraded_direct_delay;end
 for item={'raw_edge','raw_local'}
  kind=item{1};d=delay;if strcmp(kind,'raw_edge'),d=cfg.e3_uplink_delay;end
  net.arrivals{end+1}=struct('kind',kind,'at',finish+d,'sender',j,'value',p);
 end
end
% Sensor adapter is the only use of neighboring truth outside plant audits.
if mod(k,round(cfg.e3_sensor_period/cfg.Ts))==0
 for j=1:3
  obs=struct('position',x(7:9,j)+cfg.edge_observation_radius*net.sensor_noise(:,j,k+1),'step',k,'radius',cfg.edge_observation_radius);
  [net,finish]=transmit(net,t,cfg.e3_sensor_bits,'sensor',j,k+1,cfg);
  net.arrivals{end+1}=struct('kind','sensor','at',finish+cfg.e3_sensor_delay,'sender',j,'value',obs);
  net.sensor_log{end+1}=struct('sender',j,'source',t,'arrival',finish+cfg.e3_sensor_delay,'value',obs);
 end
end
if k<round(cfg.e3_job_period/cfg.Ts) || mod(k,round(cfg.e3_job_period/cfg.Ts))~=0,return;end
for j=1:3
 % Bounded work queue: one in-flight service per source, common to all modes.
 busy=false;
 for z=1:numel(net.tasks),busy=busy || net.tasks{z}.sender==j;end
 for z=1:numel(net.arrivals),a=net.arrivals{z};busy=busy || (strcmp(a.kind,'service') && a.sender==j);end
 if busy
  net.choices{end+1}=struct('job',0,'release',t,'sender',j,'chosen','BUSY','scores',[-inf -inf -inf], ...
   'expected_gain',[0 0 0],'local_source',-1,'edge_source',-1,'observation_time',-1,'budget',net.budget(j),'predicted_delivery',[t t t]);
  continue;
 end
 ticid=tic;
 local=net.raw_local{j};edge=net.raw_edge{j};forward=edge;
 if ~isfield(local,'velocity_source_step'),local.velocity_source_step=local.step;end
 if ~isfield(edge,'velocity_source_step'),edge.velocity_source_step=edge.step;forward.velocity_source_step=edge.step;end
 obs=net.observations{j};obs_time=-1;
 if ~isempty(obs) && obs.step>=edge.step
  [pred,rad]=mechanism_packet('forecast',edge,obs.step,0,cfg,m);
  low=max(pred(7:9)-rad(7:9),obs.position-obs.radius);high=min(pred(7:9)+rad(7:9),obs.position+obs.radius);
  if all(low<=high)
   age=(obs.step-edge.step)*cfg.Ts;
   edge.state=pred;edge.state(7:9)=(low+high)/2;edge.radius=rad;edge.radius(7:9)=(high-low)/2;
   edge.velocity_radius=edge.velocity_radius(:)+cfg.acceleration_bound(:)*age;
   edge.step=obs.step;edge.source_step=obs.step;edge.expiry=obs.step+round(cfg.contract_TTL/cfg.Ts);obs_time=obs.step*cfg.Ts;
  end
 end
 cpu_edge=cfg.e3_edge_cpu;if in_windows(t,cfg.e3_congestion_windows),cpu_edge=cfg.e3_congested_cpu;end
 choices={'LOCAL','EDGE','SKIP'};candidates={local,edge,[]};
 ready=[max(t,net.local_cpu_until(j))+cfg.e3_local_cpu,max(t,net.edge_cpu_until)+cpu_edge,t];
 delivery=[ready(1)+cfg.Ts,max(ready(2),net.busy_until)+cfg.packet_bits/cfg.channel_bitrate+cfg.e3_downlink_delay+cfg.Ts,t+cfg.e3_skip_horizon];
 scores=-inf(1,3);expected_gain=zeros(1,3);
 for q=1:3
  at=ceil(delivery(q)/cfg.Ts);held=0;
  for i=1:3,if i==j,continue;end;[~,rr]=mechanism_packet('forecast',packets{i,j},at,cfg.cooperative_horizon,cfg,m);held=max(held,max(rr(8,:)));end
  if q==3,after=held;
  else,[~,rr]=mechanism_packet('forecast',candidates{q},at,cfg.cooperative_horizon,cfg,m);after=max(rr(8,:));end
  expected_gain(q)=held-after;cost=0;if q==2,cost=cfg.edge_bit_cost*cfg.packet_bits;end
  scores(q)=-after/max(.01,net.budget(j))-cfg.adaptive_latency_weight*(delivery(q)-t)-cost;
  if q<3 && expected_gain(q)<=1e-9,scores(q)=-inf;end
 end
 if strcmp(mode,'ADAPTIVE'),[~,choice]=max(scores);chosen=choices{choice};
 else,chosen=mode;end
 net.nextid=net.nextid+1;
 net.choices{end+1}=struct('job',net.nextid,'release',t,'sender',j,'chosen',chosen,'scores',scores,'expected_gain',expected_gain, ...
  'local_source',local.source_step*cfg.Ts,'edge_source',edge.source_step*cfg.Ts,'observation_time',obs_time,'budget',net.budget(j),'predicted_delivery',delivery);
 if strcmp(chosen,'SKIP'),continue;end
 bits=cfg.packet_bits;cpu=0;ob=-1;
 switch chosen
  case 'LOCAL',p=local;cpu=cfg.e3_local_cpu;bits=0;rd=ready(1);net.local_cpu_until(j)=rd;rawtime=local.source_step*cfg.Ts;
  case 'EDGE',p=edge;cpu=cpu_edge;rd=ready(2);net.edge_cpu_until=rd;ob=obs_time;rawtime=forward.source_step*cfg.Ts;
  case 'FORWARD',p=forward;rd=t;rawtime=forward.source_step*cfg.Ts;
 end
 p.version=100000+net.nextid;
 job=struct('id',net.nextid,'sender',j,'choice',chosen,'packet',p,'release',t,'ready',rd, ...
  'bits',bits,'cpu',cpu,'raw_source_time',rawtime,'observation_time',ob,'algorithm_seconds',toc(ticid));
 net.tasks{end+1}=job;
end
end
function [net,finish]=transmit(net,t,bits,kind,sender,id,cfg)
start=max(t,net.busy_until);finish=start+bits/cfg.channel_bitrate;net.busy_until=finish;net.bits=net.bits+bits;
net.txlog{end+1}=struct('start',start,'finish',finish,'bits',bits,'kind',kind,'sender',sender,'id',id,'release',t);
end
function yes=in_windows(t,windows)
yes=any(t>=windows(:,1) & t<windows(:,2));
end
function p=forecast_position(packet,k,cfg,m)
[v,~]=mechanism_packet('forecast',packet,k,0,cfg,m);p=v(7:9);
end
function r=forecast_radius(packet,k,cfg,m)
[~,v]=mechanism_packet('forecast',packet,k,0,cfg,m);r=v(7:9);
end
