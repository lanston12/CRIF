function [margin,chi,support]=study_pair_value(own,plan,p,k,i,j,cfg,m)
% Receiver-local calculation, identical horizon and certificate as MPC.
H=cfg.cooperative_horizon;t=k*cfg.Ts;
[pred,rad]=mechanism_packet('forecast',p,k,H,cfg,m);
ri=mechanism_reference(t+(0:H)*cfg.Ts,i,'E3',cfg,m);
rj=mechanism_reference(t+(0:H)*cfg.Ts,j,'E3',cfg,m);
xx=own;pp=zeros(1,H+1);pp(1)=own(8);held=plan(:,[2:end end]);
for a=1:H
 b=m.trim.x;b(7)=b(7)+1.5*(t+(a-1)*cfg.Ts);bn=b;bn(7)=bn(7)+1.5*cfg.Ts;
 xx=bn+m.A*(xx-b)+m.B*(held(:,a)-m.trim.command);pp(a+1)=xx(8);
end
sg=sign(ri(8,1)-rj(8,1));if sg==0,sg=1;end
budget=min(sg*(pp-pred(8,:))-cfg.safety_distance-cfg.own_position_reserve(2), ...
 cfg.formation_bound-abs(pp-pred(8,:)-(ri(8,:)-rj(8,:)))-cfg.own_position_reserve(2));
margin=min(budget-rad(8,:));chi=max(rad(8,:)./max(.01,budget));support=rad(8,1);
end
