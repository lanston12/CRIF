function run_study_batch(jobfile,part,parts)
maxNumCompThreads(1);startup_smoke();jobs=jsondecode(fileread(jobfile));
for z=part:parts:numel(jobs)
 j=jobs(z);cfg=jsondecode(fileread(j.config));
 p=fullfile('logs','mechanisms',j.stage,cfg.version,sprintf('%s_%s_%d.mat',j.experiment,j.method,j.seed));
 if isfile(p),fprintf('PRESERVED existing %s\n',p);continue;end
 run_statistical_study(j.config,j.experiment,j.method,j.seed,j.stage);
end
end
