function ref=mechanism_reference(t,id,experiment,cfg,m)
t=t(:)';ref=repmat(m.trim.x,1,numel(t));
ref(7,:)=m.trim.x(7)+1.5*t;
ref(8,:)=cfg.path_east_amplitude*sin(cfg.path_east_frequency*t);
ref(9,:)=40+cfg.path_down_amplitude*sin(cfg.path_down_frequency*t);
ve=cfg.path_east_amplitude*cfg.path_east_frequency*cos(cfg.path_east_frequency*t);
vd=cfg.path_down_amplitude*cfg.path_down_frequency*cos(cfg.path_down_frequency*t);
offset=cfg.far_offset*ones(size(t));vel=zeros(size(t));
if ~strcmp(experiment,'C1') && ~strcmp(experiment,'C2')
 mid=(cfg.interaction_start+cfg.interaction_end)/2;half=(cfg.interaction_end-cfg.interaction_start)/2;
 inside=abs(t-mid)<half;z=(t(inside)-mid)/half;
 shape=(1+cos(pi*z))/2;
 offset(inside)=cfg.far_offset-(cfg.far_offset-cfg.near_offset)*shape;
 vel(inside)=(cfg.far_offset-cfg.near_offset)*pi/(2*half)*sin(pi*z);
end
sg=[0 1 -1];ref(8,:)=ref(8,:)+sg(id)*offset;
ref(12,:)=atan2(ve+sg(id)*vel,1.5);
ref(11,:)=-atan2(vd,1.5);
% Desired body speed accounts for the geometrical lateral path rate.
ref(1,:)=sqrt(1.5^2+(ve+sg(id)*vel).^2+vd.^2);
end
