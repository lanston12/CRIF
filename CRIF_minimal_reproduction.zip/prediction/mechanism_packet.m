function varargout=mechanism_packet(action,varargin)
switch action
 case 'create',varargout{1}=create(varargin{:});
 case 'forecast',[varargout{1:nargout}]=forecast(varargin{:});
 case 'bounds',[varargout{1:nargout}]=bounds(varargin{:});
 case 'accept',[varargout{1:nargout}]=accept(varargin{:});
end
end
function p=create(x,U,step,id,cfg,model,version)
q=cfg.quantization(:);p=struct('state',round(x./q).*q,'U',U,'step',step, ...
 'id',id,'version',version,'expiry',step+round(cfg.contract_TTL/cfg.Ts), ...
 'model','MSS98970-linear12','radius',q/2,'source_step',step,'base_version',0);
assert(all(abs(x-p.state)<=p.radius+1e-12));
if isfield(cfg,'forecast_mode') && strcmp(cfg.forecast_mode,'CV_ACCELERATION_CONTRACT')
 p.velocity=Rzyx(x(10),x(11),x(12))*x(1:3);p.velocity=round(p.velocity/.002)*.002;
 p.velocity_radius=cfg.velocity_error(:);
 p.model='CV6_empirical_acceleration_contract';p.input_plan_status='advisory_not_an_input_commitment';
end
end
function [x,r,expired]=forecast(p,step,H,cfg,m)
% Retain the full box-generator images when computing supports; no stale truth.
age=step-p.step;assert(age>=0);x=p.state;r=zeros(12,H+1);xx=zeros(12,H+1);
if isfield(cfg,'forecast_mode') && strcmp(cfg.forecast_mode,'CV_ACCELERATION_CONTRACT')
 for a=0:H
  tau=(age+a)*cfg.Ts;xx(:,a+1)=p.state;xx(7:9,a+1)=p.state(7:9)+tau*p.velocity;
  r(:,a+1)=p.radius;cap=min(tau,cfg.contract_TTL);
  r(7:9,a+1)=p.radius(7:9)+p.velocity_radius(:)*cap+.5*cfg.acceleration_bound(:)*cap^2+cfg.expired_velocity_error*max(0,tau-cfg.contract_TTL);
 end
 x=xx;expired=step>p.expiry;return;
end
for a=0:age+H
 if a>=age
  ix=a-age+1;xx(:,ix)=x;
  late=max(0,a-(p.expiry-p.step+1));
  r(:,ix)=cfg.noise_support(:,a+1)+cfg.expired_extra(:,late+1)+cfg.abs_power(:,:,a+1)*p.radius;
 end
 if a<age+H
  u=p.U(:,min(a+1,size(p.U,2)));
  base=m.trim.x;base(7)=base(7)+(p.step+a)*cfg.Ts*1.5;
  nextbase=base;nextbase(7)=nextbase(7)+cfg.Ts*1.5;
  x=nextbase+m.A*(x-base)+m.B*(u-m.trim.command);
 end
end
x=xx;expired=step>p.expiry;
end
function [lo,hi]=bounds(contracts,step,N,cfg)
lo=repmat(cfg.input_floor(:),1,N);hi=repmat(cfg.input_limit(:),1,N);
if isfield(cfg,'forecast_mode') && strcmp(cfg.forecast_mode,'CV_ACCELERATION_CONTRACT'),return;end
for j=1:numel(contracts)
 p=contracts{j};
 for k=1:N
  at=step+k-1;
  if at>=p.step && at<=p.expiry
   u=p.U(:,min(at-p.step+1,size(p.U,2)));
   lo(:,k)=max(lo(:,k),u-cfg.contract_beta(:));hi(:,k)=min(hi(:,k),u+cfg.contract_beta(:));
  end
 end
end
assert(all(lo(:)<=hi(:)+1e-9),'MECHANISM:ContractConflict','Inconsistent live input commitments');
end
function [stored,accepted]=accept(old,new,at)
accepted=new.id==old.id && strcmp(new.model,old.model) && new.version>old.version ...
 && new.source_step>=old.source_step && new.step<=at && new.expiry>=at && new.base_version==0;
stored=old;if accepted,stored=new;end
end
